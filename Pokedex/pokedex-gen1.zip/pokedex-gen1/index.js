require('dotenv').config();
const express = require('express');
const cors = require('cors');
const multer = require('multer');
const { GoogleGenAI } = require('@google/genai');
const pokemonsLocales = require('./pokemons.json');

const app = express();
const PORT = process.env.PORT || 3000;

const upload = multer({ storage: multer.memoryStorage() });
const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// Función auxiliar para obtener datos, audio y descripción desde PokeAPI
async function fetchPokeAPI(search) {
  try {
    const res = await fetch(`https://pokeapi.co/api/v2/pokemon/${search.toString().toLowerCase()}`);
    if (!res.ok) return null;
    const data = await res.json();
    
    if (data.id > 151) {
      return { outOfRange: true };
    }

    // 1. Garantizar URL de audio válida
    let cryUrl = null;
    if (data.cries) {
      cryUrl = data.cries.latest || data.cries.legacy;
    }
    if (!cryUrl && data.id) {
      cryUrl = `https://raw.githubusercontent.com/PokeAPI/cries/main/cries/pokemon/latest/${data.id}.ogg`;
    }

    // 2. Obtener la descripción oficial en español desde species
    let description = "Sin descripción disponible.";
    try {
      const speciesRes = await fetch(`https://pokeapi.co/api/v2/pokemon-species/${data.id}`);
      if (speciesRes.ok) {
        const speciesData = await speciesRes.json();
        const spanishEntry = speciesData.flavor_text_entries.find(
          entry => entry.language.name === 'es'
        );
        if (spanishEntry) {
          description = spanishEntry.flavor_text.replace(/[\n\f]/g, ' ');
        }
      }
    } catch (descError) {
      console.warn("No se pudo obtener la descripción:", descError);
    }

    return {
      id: data.id,
      name: data.name,
      sprite: data.sprites.other['official-artwork'].front_default,
      cries: cryUrl,
      description: description,
      types: data.types.map(t => t.type.name),
      base_stats: {
        hp: data.stats[0].base_stat,
        attack: data.stats[1].base_stat,
        defense: data.stats[2].base_stat,
        speed: data.stats[5].base_stat
      }
    };
  } catch (error) {
    console.error("Error al consultar PokeAPI:", error);
    return null;
  }
}

// Endpoint 1: Obtener lista de los 151
app.get('/api/v1/pokemon', async (req, res) => {
  try {
    const response = await fetch('https://pokeapi.co/api/v2/pokemon?limit=151');
    const data = await response.json();
    res.json({ total: 151, results: data.results });
  } catch (error) {
    res.status(500).json({ error: "Error al obtener lista de Pokémon" });
  }
});

// Endpoint 2: Buscar por ID o Nombre (1-151)
app.get('/api/v1/pokemon/:search', async (req, res) => {
  const { search } = req.params;
  const officialData = await fetchPokeAPI(search);

  if (officialData && officialData.outOfRange) {
    return res.status(400).json({ error: 'Solo se permiten los primeros 151 Pokémon.' });
  }

  const localData = pokemonsLocales.find(p => 
    p.id === Number(search) || p.name.toLowerCase() === search.toLowerCase()
  );

  if (!officialData && !localData) {
    return res.status(404).json({ error: 'Pokémon no encontrado en la lista 1-151.' });
  }

  res.json({
    official_data: officialData,
    custom_data: localData ? localData.custom_data : "Sin datos personalizados"
  });
});

// Endpoint 3: Identificar mediante IA (Restringido a Gen 1)
app.post('/api/v1/ai/identify', upload.single('image'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'Sube una imagen usando el campo "image"' });
    }

    const imagePart = {
      inlineData: {
        data: req.file.buffer.toString("base64"),
        mimeType: req.file.mimetype
      },
    };

    const prompt = `Analiza esta imagen e identifica qué Pokémon es. 
    REGLA ESTRICTA: Solo identifica si pertenece a los PRIMEROS 151 (Kanto).
    Si es de generaciones posteriores (ID > 151) o no es un Pokémon, responde "detected": false.

    Responde ÚNICAMENTE en JSON válido con este formato:
    {
      "detected": true/false,
      "pokemon_name": "nombre_en_minusculas",
      "confidence": "Alta/Media/Baja"
    }`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: [prompt, imagePart],
    });

    const cleanJson = response.text.replace(/```json|```/g, '').trim();
    const result = JSON.parse(cleanJson);

    if (result.detected && result.pokemon_name) {
      const officialData = await fetchPokeAPI(result.pokemon_name);

      if (officialData && officialData.outOfRange) {
        return res.json({
          detected: false,
          message: "El Pokémon no pertenece a los primeros 151."
        });
      }

      const localData = pokemonsLocales.find(p => p.name.toLowerCase() === result.pokemon_name.toLowerCase());

      result.pokedex_entry = {
        official: officialData,
        custom: localData ? localData.custom_data : null
      };
    }

    res.json(result);
  } catch (error) {
    console.error("Error en IA:", error);
    res.status(500).json({ error: "Error al procesar la imagen con IA" });
  }
});

app.listen(PORT, () => {
  console.log(`Servidor activo en http://localhost:${PORT}`);
});